class Main3{

public static void main(String[] args) {
    
		FullTimeEmployee fullTime = new FullTimeEmployee("Adnan", "F24-ARI", 5000);

        PartTimeEmployee partTime = new PartTimeEmployee("Adil","F24-ARI",75, 25);

        System.out.println("Salary of " + fullTime.name + ": PKR" + fullTime.calculateSalary());
        fullTime.payTax();

        System.out.println("Salary of " + partTime.name + ": PKR" + partTime.calculateSalary());
        partTime.payTax();
    
	}	
}