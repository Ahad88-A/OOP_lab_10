class Car implements Vehicle{
	void start(){
		System.out.println("Car is Started .");
	}

	 void stop(){
	 	System.out.println("Car is stopped .");
	 }
}