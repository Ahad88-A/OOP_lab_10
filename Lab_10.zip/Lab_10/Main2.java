class Main2{
	public static void main(String[] args) {
		Car c = new Car();
		Bike b = new Bike();

		b.start();
		b.stop();

		c.start();
		c.stop();
	}
}