interface Swimmable{
	void swim();
}