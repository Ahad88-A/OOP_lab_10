class FullTimeEmployee extends Employee  implements TaxPayer{
	
	double salary;

	FullTimeEmployee(String name,String id,double salary){
		super(name,id);
		this.salary=salary;
	}

	public double calculateSalary(){
		return salary;
	}

	public void payTax(){
		System.out.println(name + " Full-Time - - -paid " + (0.2 * salary));
	}
	
}