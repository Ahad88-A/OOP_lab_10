class Rectangle extends Shape implements Printable{


	double w ;
	double h ;
	Rectangle(double w , double h){
		this.w=w;
		this.h=h;
	}


	double area(){
    return w*h;

	}

	void print(){
	System.out.println("Printing Area . ");
}
			public static void main(String[] args) {
		Rectangle a= new Rectangle(5.5,6.5);

	double Area = a.area();
	System.out.println("Area is . "+Area);
		a.print();

	}

}