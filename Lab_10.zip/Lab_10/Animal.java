abstract class Animal{
	abstract void makeSound();

	void eat(){
		System.out.println("Animal is eating .");
	}
	
}